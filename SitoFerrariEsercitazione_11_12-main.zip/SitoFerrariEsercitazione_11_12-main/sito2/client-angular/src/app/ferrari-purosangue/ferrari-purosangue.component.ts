import { Component } from '@angular/core';

@Component({
  selector: 'app-ferrari-purosangue',
  standalone: true,
  imports: [],
  templateUrl: './ferrari-purosangue.component.html',
  styleUrl: './ferrari-purosangue.component.css'
})
export class FerrariPurosangueComponent {

}
