import { Component } from '@angular/core';

@Component({
  selector: 'app-ferrari-sf90',
  standalone: true,
  imports: [],
  templateUrl: './ferrari-sf90.component.html',
  styleUrl: './ferrari-sf90.component.css'
})
export class FerrariSf90Component {

}
