import { Component } from '@angular/core';

@Component({
  selector: 'app-ferrari-mythos',
  standalone: true,
  imports: [],
  templateUrl: './ferrari-mythos.component.html',
  styleUrl: './ferrari-mythos.component.css'
})
export class FerrariMythosComponent {

}
