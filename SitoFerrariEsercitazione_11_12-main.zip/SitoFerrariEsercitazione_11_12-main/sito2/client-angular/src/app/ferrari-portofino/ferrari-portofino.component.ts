import { Component } from '@angular/core';

@Component({
  selector: 'app-ferrari-portofino',
  standalone: true,
  imports: [],
  templateUrl: './ferrari-portofino.component.html',
  styleUrl: './ferrari-portofino.component.css'
})
export class FerrariPortofinoComponent {

}
