import { Component } from '@angular/core';

@Component({
  selector: 'app-ferrari-488',
  standalone: true,
  imports: [],
  templateUrl: './ferrari-488.component.html',
  styleUrl: './ferrari-488.component.css'
})
export class Ferrari488Component {

}
