import { Component } from '@angular/core';

@Component({
  selector: 'app-ferrari-pininfarina',
  standalone: true,
  imports: [],
  templateUrl: './ferrari-pininfarina.component.html',
  styleUrl: './ferrari-pininfarina.component.css'
})
export class FerrariPininfarinaComponent {

}
